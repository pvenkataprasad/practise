//
//  AppDelegate.h
//  JSONExample
//
//  Created by AsquareMobileTechnologies on 1/10/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

