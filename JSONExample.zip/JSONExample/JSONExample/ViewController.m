//
//  ViewController.m
//  JSONExample
//
//  Created by AsquareMobileTechnologies on 1/10/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([[defaults objectForKey:@"Email"] length] != 0) {
        txtEmail.text = [defaults objectForKey:@"Email"];
        txtPassword.text = [defaults objectForKey:@"Password"];
        remindSwt.on = YES;

    }
    // Do any additional setup after loading the view, typically from a nib.
}
#pragma mark ServiceCall
-(void)postDataToUrl
{
    __block NSDictionary* responseData = nil;
    

    NSString *urlString = @"http://www.asquaretechnologies.net/asquare/api/login";
    NSString *inputData2 = [NSString stringWithFormat:@"email=%@&password=%@",txtEmail.text,txtPassword.text];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    
    
    
    
    NSMutableData *body = [NSMutableData data];
    
    [body appendData:[[NSString stringWithFormat:@"%@",inputData2] dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];
    [request setHTTPBody:body];
    [request setHTTPMethod:@"POST"];
    [NSURLConnection sendAsynchronousRequest: request
                                       queue: queue
                           completionHandler: ^(NSURLResponse *response, NSData *data, NSError *error) {
                               if (error || !data) {
                                   // Handle the error
                                   
                                   NSLog(@"Server Error : %@", error);

                               } else {
                                   // Handle the success
                                   
                                   NSLog(@"Server Response :%@",response);
                                   NSString *strResponse = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
                                   responseData             = [NSJSONSerialization JSONObjectWithData: [[NSString stringWithFormat:@"%@",strResponse] dataUsingEncoding:NSUTF8StringEncoding]
                                                                                            options: NSJSONReadingMutableContainers
                                                                                              error: &error];
                                   NSLog(@"%@",responseData);
                                   [self returnOutput:responseData];
                                   
                               }

                           }
     
     ];
    
}
#pragma mark ServiceCall2
-(void)returnOutput:(NSDictionary*)output{
    NSLog(@"%@",output);
    if ([[output objectForKey:@"status"] isEqualToString:@"Fail"]) {
//        [self showAlert:[output objectForKey:@"msg"]];
    }else{
        
    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnLoginClicked:(id)sender {
    if ([self LoginValidation])// Login Validation Code if it is giving True
    {
        
        if ([self NSStringIsValidEmail:txtEmail.text]) {   // Email validation is true execute service
            if (remindSwt.on) {
                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                [defaults setObject:txtEmail.text forKey:@"Email"];
                [defaults setObject:txtPassword.text forKey:@"Password"];
                [self postDataToUrl];
            }
            
            
        }else{
            [self showAlert:@"Please Enter Valid Email"];
 
        }
    }
    
}
-(void)showAlert:(NSString*)edit{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"ASqaure" message:edit delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alert show];
}

-(BOOL) NSStringIsValidEmail:(NSString *)checkString // Email Valdation Code
{
    BOOL stricterFilter = NO; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}
-(BOOL)LoginValidation{
    if ([txtEmail.text length] == 0 && [txtPassword.text length] == 0) {
        [self showAlert:@"Please Enter Email & Password"];
    }else if ([txtEmail.text length] == 0) {
        [self showAlert:@"Please Enter Email"];
    }else if ([txtPassword.text length] == 0) {
        [self showAlert:@"Please Enter Password"];
    }else{
        return  TRUE;
    }
    return FALSE;
}
@end
