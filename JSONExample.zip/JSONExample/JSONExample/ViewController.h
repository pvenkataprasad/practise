//
//  ViewController.h
//  JSONExample
//
//  Created by AsquareMobileTechnologies on 1/10/16.
//  Copyright © 2016 AsquareMobileTechnologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    
    __weak IBOutlet UITextField *txtEmail;
    __weak IBOutlet UITextField *txtPassword;
    __weak IBOutlet UISwitch *remindSwt;
}

- (IBAction)btnLoginClicked:(id)sender;

@end

